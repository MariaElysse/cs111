//
// Created by maria on 4/12/17.
//
#include <stdlib.h>
#include <stdbool.h>

#ifndef LAB1_TEST_H
#define LAB1_TEST_H

size_t sanitize_crlf(char *buffer, size_t buffer_len); //from lab1a.c source file
#endif //LAB1_TEST_H
